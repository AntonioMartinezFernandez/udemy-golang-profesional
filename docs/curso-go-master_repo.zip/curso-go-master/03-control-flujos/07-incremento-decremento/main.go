package main

import "fmt"

func main() {

	a := 0

	//Operador de incremento
	a++
	a++
	a++
	a++
	a++
	fmt.Println(a)

	//Operador de decremento

	a--
	a--
	a--
	a--
	fmt.Println(a)
}
