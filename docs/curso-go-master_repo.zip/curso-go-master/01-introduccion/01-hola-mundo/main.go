package main

import "fmt"

func main() {
	fmt.Println("Hola desde otro archivo")
}
