package main

import "fmt"

func main() {

	var nombre1 string
	nombre1 = "Alex"

	var nombre2 string = "Roel"

	edad := 26

	fmt.Println(nombre1, nombre2, edad)

	var a int
	var b float64
	var c string
	var d bool

	fmt.Println(a, b, c, d)

	const pi = 3.141592
	fmt.Println(pi)

}
